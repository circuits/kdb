# Filename: __init__.py
# Module:   __init__
# Date:     04th August 2004
# Author:   James Mills <prologic@shortcircuit.net.au>

"__init__"

__name__ = "kdb"
__desc__ = "Knowledge (IRC) Bot"
__version__ = "0.0.1"
__author__ = "James Mills"
__email__ = "%s <prologic@shortcircuit.net.au>" % __author__
__url__ = "http://shortcircuit.net.au/~prologic/"
__copyright__ = "CopyRight (C) 2005 by %s" % __author__
__str__ = "%s-%s" % (__name__, __version__)
